
using UnityEngine;
using UnityEngine.SceneManagement;

public class PlayerBehaviour : MonoBehaviour
{
    public float _baseVel;
    public float _baseDeccel;
    private float _Vel;
    public float _accel;
    public float _deccel;
    public float _maxVel;
    public float _upGravity;
    public float _downGravity;
    public float _jumpForce;

    private bool _goLeft = false;
    private bool _stop = false;
    private bool _jump = false;
    private Transform _transform;
    private Rigidbody2D _rb;
    public GameObject _particles;
    private GameObject particle;
    // Start is called before the first frame update
    void Start()
    {
        _Vel = 0;
       _transform = gameObject.GetComponent<Transform>();
        _rb = gameObject.GetComponent<Rigidbody2D>();
        particle = GameObject.FindGameObjectWithTag("particle");
    }

    // Update is called once per frame
    void Update()
    {
        if (Input.GetKeyDown(KeyCode.RightArrow)) { _Vel += _baseVel; _stop = false; }
        else if (Input.GetKeyDown(KeyCode.LeftArrow)) { _Vel -= _baseVel; _stop = false; }

        if (Input.GetKey(KeyCode.RightArrow) && _jump) { RunR(); }
        else if (Input.GetKey(KeyCode.LeftArrow) && _jump) { RunL(); }

        if (Input.GetKeyUp(KeyCode.RightArrow ) && _Vel >= 0.25f) { _Vel -= _baseDeccel; _stop = true; }
        else if (Input.GetKeyUp(KeyCode.LeftArrow) && _Vel <= 0.25f) { _Vel += _baseDeccel; _stop = true; }

        if (_stop == true && !_goLeft)  { StopR();}
        else if (_stop == true && _goLeft) { StopL(); }

        if (Input.GetKeyDown(KeyCode.LeftArrow)){ _goLeft = true; }
        else if (Input.GetKeyDown(KeyCode.RightArrow) || _Vel == 0) {  _goLeft = false; }

        if ( _Vel >= _maxVel){ _Vel = _maxVel; }
        else if (_Vel <= -_maxVel) { _Vel = -_maxVel; }

        if (!_goLeft) { _transform.localPosition += Vector3.right * _Vel * Time.deltaTime; }
        else { _transform.localPosition -= Vector3.left * _Vel * Time.deltaTime; }

        if (_rb.velocity.y < -1) { _rb.gravityScale = _downGravity; }
        if (!_jump && _rb.velocity.y < 1 && _rb.velocity.y > -1) { _rb.gravityScale = _upGravity; }
        if (Input.GetKeyDown(KeyCode.Space) && _jump) 
        {
            _jump = false;
            GetComponent<Animator>().SetBool("Walk", false);
            _rb.AddForce(Vector2.up * _jumpForce, ForceMode2D.Impulse);
            particle = GameObject.FindGameObjectWithTag("particle");
            Destroy(particle);
           
        }

        if(_transform.localPosition.y < -4.73) { _transform.position = new Vector2(_transform.localPosition.x, -4.72f); }
        

    }



      

    private void RunR()
    {
        GetComponent<Animator>().SetBool("Walk", true);
        _Vel += _accel * Time.deltaTime;
    }
    private void RunL()
    {
        GetComponent<Animator>().SetBool("Walk", true);
        _Vel -= _accel * Time.deltaTime;
    }
    private void StopR()
    {
        
        _Vel -= _deccel * Time.deltaTime;
        if (_Vel <= 0) { _Vel = 0; _stop = false; GetComponent<Animator>().SetBool("Walk", false); }
       
    }
    private void StopL()
    {

        _Vel += _deccel * Time.deltaTime;
        if (_Vel >= 0) { _Vel = 0; _stop = false; GetComponent<Animator>().SetBool("Walk", false); }

    }

    private void OnCollisionEnter2D(Collision2D collision)
    {
        if (collision.gameObject.layer == 6) 
        {  
        _jump = true;
        _rb.gravityScale = 1;
        Instantiate(_particles, new Vector2(_transform.position.x, _transform.position.y), Quaternion.identity);
          
        }
       
    }

}